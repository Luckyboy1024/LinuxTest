using NUnit.Core.Extensibility;

namespace Mono.Cecil.Tests {

	[NUnitAddin]
	public class CecilRocksAddin : CecilTestAddin {
	}
}
