class Foo {
	class Bar {
		class Baz {
		}
	}
}

class Bingo {
	public class Fuel {
	}

	public static Fuel GetFuel ()
	{
		return null;
	}
}
