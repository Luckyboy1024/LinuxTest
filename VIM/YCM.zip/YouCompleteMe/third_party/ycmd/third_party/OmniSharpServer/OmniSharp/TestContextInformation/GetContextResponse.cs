namespace OmniSharp.TestContextInformation
{
    public class GetContextResponse
    {
        public string AssemblyName { get; set; }
        public string TypeName { get; set; }
        public string MethodName { get; set; }
    }
}