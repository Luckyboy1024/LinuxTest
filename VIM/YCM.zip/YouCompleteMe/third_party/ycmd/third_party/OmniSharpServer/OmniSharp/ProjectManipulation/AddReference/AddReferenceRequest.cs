﻿using OmniSharp.Common;

namespace OmniSharp.ProjectManipulation.AddReference
{
    public class AddReferenceRequest : Request
    {
        public string Reference { get; set; }
    }
}