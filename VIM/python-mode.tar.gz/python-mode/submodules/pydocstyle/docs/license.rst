License
=======

.. include:: ../LICENSE-MIT
