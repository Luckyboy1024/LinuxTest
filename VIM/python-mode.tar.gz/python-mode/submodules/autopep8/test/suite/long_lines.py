if True:
    if True:
        if True:
            self.__heap.sort()  # pylint: builtin sort probably faster than O(n)-time heapify

            if True:
                foo = '(                                                '+array[0] +'                    '
