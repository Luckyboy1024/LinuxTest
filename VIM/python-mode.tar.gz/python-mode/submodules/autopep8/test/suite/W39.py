#: W391
# The next line is blank

#: Okay
'''there is nothing wrong
with a multiline string at EOF

that happens to have a blank line in it
'''
