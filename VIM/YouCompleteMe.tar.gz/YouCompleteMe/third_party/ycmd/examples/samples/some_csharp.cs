using System;

namespace some_csharp
{
  class MainClass
  {
    public static void Main (string[] args)
    {
      // location after second dot is line 9, column 15
      Console.
    }
  }
}
