//! Provider for finding definitions

include!(concat!(env!("OUT_DIR"), "/http/definition.rs"));
