//! Som misc shared functionality
pub mod fs;
