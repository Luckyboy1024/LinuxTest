include!(concat!(env!("OUT_DIR"), "/http/completion.rs"));
