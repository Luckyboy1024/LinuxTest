//! Engines provide source analysis for rust code

include!(concat!(env!("OUT_DIR"), "/engine/mod.rs"));
