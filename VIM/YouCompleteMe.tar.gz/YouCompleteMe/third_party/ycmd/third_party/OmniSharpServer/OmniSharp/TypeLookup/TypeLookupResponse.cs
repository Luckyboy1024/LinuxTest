﻿namespace OmniSharp.TypeLookup
{
    public class TypeLookupResponse
    {
        public string Type;
        public string Documentation;
    }
}
