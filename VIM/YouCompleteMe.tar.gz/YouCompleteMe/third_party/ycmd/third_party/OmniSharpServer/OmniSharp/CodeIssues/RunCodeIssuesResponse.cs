﻿namespace OmniSharp.CodeIssues
{
    public class RunCodeIssuesResponse
    {
        public string Text { get; set; }
    }
}