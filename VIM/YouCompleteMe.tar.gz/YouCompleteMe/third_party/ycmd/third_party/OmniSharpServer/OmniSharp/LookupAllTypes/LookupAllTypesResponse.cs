﻿namespace OmniSharp.LookupAllTypes
{
    public class LookupAllTypesResponse
    {
        public string Types { get; set; }
        public string Interfaces { get; set; }
    }
}
