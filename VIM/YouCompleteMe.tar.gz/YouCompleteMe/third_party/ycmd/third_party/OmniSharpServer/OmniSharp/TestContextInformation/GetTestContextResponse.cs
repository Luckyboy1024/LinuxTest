﻿namespace OmniSharp.TestContextInformation
{
    public class GetTestContextResponse
    {
        public string TestCommand { get; set; }
    }
}