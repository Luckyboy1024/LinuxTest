<!-- Before reporting:
Search existing issues and check the FAQ.
Make sure that you have the latest version of LeaderF.
-->

- vim or neovim?
    - [ ] vim
    - [ ] neovim
- `vim --version` or `nvim --version`:

- Output of `:echo has("python")`: 
- Output of `:echo has("python3")`: 
- Output of `:echo &pythondll`(only vim, not neovim): 
- Output of `:echo &pythonthreedll`(only vim, not neovim): 
- Output of `:py print(sys.version)`: 
- Output of `:py3 print(sys.version)`: 
- Operating system: 
    - [ ] Linux
    - [ ] Mac OS X
    - [ ] Windows
    - [ ] Etc.
- Configurations related to LeaderF in vimrc: 

### Describe your question, feature request, or bug.

### Steps to reproduce

### Actual behaviour

### Expected behaviour

