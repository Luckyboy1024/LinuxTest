- Structured, independent, reproducible tests.
- More integration tests.
- Register buffer modified notification instead of TextChanged autocmd. Wait
  for https://github.com/neovim/neovim/pull/5269 to be merged in.
- Check server capabilities before calling RPC API.
- Replace echodoc functionality.
