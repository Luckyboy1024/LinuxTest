
pub fn yo() -> i32 {
    let a = 1;
    let b = a + a;
    42
}
