package main; var a int
